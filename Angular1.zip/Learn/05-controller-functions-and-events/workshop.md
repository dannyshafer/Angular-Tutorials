# Workshop for this step

1. Add an event function to controller
2. Add a button to the html that uses that event function
3. Extra credit: Add a button that logs the list item that it is associated with
