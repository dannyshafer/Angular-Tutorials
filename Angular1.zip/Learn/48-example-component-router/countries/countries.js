(function (angular) {
  'use strict';

  angular.module('countries', ['countryList', 'countryDetail'])
    .component('countries', {
      template: '<h2>Countries</h2><ng-outlet></ng-outlet>',
      $routeConfig: [
        { path: '/', name: 'CountryList', component: 'countryList', useAsDefault: true },
        { path: '/:id', name: 'CountryDetail', component: 'countryDetail' }
      ]
    });

})(window.angular);
