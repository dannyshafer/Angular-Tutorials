(function (angular) {
  'use strict';

  angular.module('countryDetail', [])
    .component('countryDetail', {
      templateUrl: 'countries/detail/country-detail.html',
      controller: CountryDetailController
    });

  function CountryDetailController() {
    this.$routerOnActivate = function (next) {
      this.countryCode = next.params.id;
    };
  }

})(window.angular);
