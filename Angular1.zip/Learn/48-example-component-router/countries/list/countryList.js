(function(angular) {
  'use strict';

  angular.module('countryList', ['countryDetail'])
    .component('countryList', {
      templateUrl: 'countries/list/country-list.html',
      controller: CountryListController,
      controllerAs: 'cl'
    });

  function CountryListController($http) {
    var clc = this;
    $http.get('../demo-data/countries.json').then(function (response) {
      clc.countries = response.data;
    });

    clc.orderProp = 'countryName';
  }

})(window.angular);
