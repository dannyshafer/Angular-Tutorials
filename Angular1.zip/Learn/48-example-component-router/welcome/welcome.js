(function(angular) {
  'use strict';

  angular.module('welcomePage', [])
    .component('welcome', {
      templateUrl: 'welcome/welcome.html'
    });

})(window.angular);
