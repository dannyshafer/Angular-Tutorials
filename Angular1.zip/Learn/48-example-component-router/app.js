(function(angular) {
  'use strict';

  angular.module('app', ['ngComponentRouter', 'welcomePage', 'countries'])
    .value('$routerRootComponent', 'myApp')
    .component('myApp', {
      templateUrl: 'main.html',
      $routeConfig: [
        {path: '/welcome', name: 'Welcome', component: 'welcome', useAsDefault: true},
        {path: '/countries/...', name: 'Countries', component: 'countries' }
      ]
    });

})(window.angular);
