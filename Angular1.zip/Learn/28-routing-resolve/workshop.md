# Workshop for this step

* Implement Resolve in your application
