# Workshop for this step

* encapsulate an unordered, ng-repeat generated list inside a directive
* Pass list and search conditions into the directive
