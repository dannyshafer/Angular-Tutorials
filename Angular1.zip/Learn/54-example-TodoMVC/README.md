# TodoMVC

This is a slighty stripped-down version of the "Angular-perf"
implementation of TodoMVC, from here:

https://github.com/tastejs/todomvc/tree/gh-pages/examples/angularjs-perf

Credits are in the HTML file.
