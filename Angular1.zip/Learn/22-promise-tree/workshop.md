# Workshop for this step

* Save the initial http request promise and hand it out every time a service function is called
* Hang another then off of your promise to log the data (NOT chained)
* Catch up on previous workshops if need be

