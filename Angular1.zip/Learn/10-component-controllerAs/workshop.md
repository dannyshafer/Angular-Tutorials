# Workshop for this step

1. Move to controllerAs usage
