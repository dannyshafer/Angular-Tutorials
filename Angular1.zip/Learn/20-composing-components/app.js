(function (angular) {
  "use strict";

  angular.module("app1", [ "exampleApp" ]);

})(window.angular);
