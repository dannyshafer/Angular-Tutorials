# Workshop for this step

* Break your application up into smaller, explicit components
* For example, make a component for each list item, if you haven't already.
* Look for an opportunity to reuse one of your components in two different places.
* Choose a file organization layout (like ours, or different), and use it.

