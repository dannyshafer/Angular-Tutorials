# Workshop for this step

1. Divide your application into at least two modules, in the same file.
2. then divide those modules into separate files.

