
These sample mobile phone data files are from the Google "Angular Phonecat" demo application.
