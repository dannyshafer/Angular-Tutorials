(function (angular) {
  "use strict";

  angular.module('exampleApp', ['time', 'drag']);

})(window.angular);
