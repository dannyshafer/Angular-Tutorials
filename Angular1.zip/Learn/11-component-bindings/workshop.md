# Workshop for this step

1. Encapsulate an unordered, ng-repeat generated list inside a component.
2. Pass list and search conditions into the component.
3. Extra credit: Create a component for entering the search conditions
