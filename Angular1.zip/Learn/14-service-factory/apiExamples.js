(function(angular) {
  'use strict';

  function ApiExampleController(myService, myFactory, justSayHello,
                                BASEAPIURL, closeToPi, justSayHelloService) {
    this.greeting1 = myService.sayHello("Joe");
    this.greeting2 = myFactory.sayHello("Joe");
    this.greeting3 = justSayHelloService.justSayHello("Joe");
    this.url = BASEAPIURL;
    this.n = closeToPi;
  }

  /* Javascript constructor functions look like this:
  function Foo() {
    this.prop1 = "eee";
  }

  var s = new Foo();

  var f = { prop1: "eee" };
  */

  function MyService( /* DI */ ) {
    // service is just a constructor function
    // that will be called with 'new'
    var mys = this;
    mys.sayHello = function (name) {
      return "Hi " + name + "!";
    };
    mys.fullGreeting = function (n) {
      return "Greetings;" + mys.sayHello(n);
    };
  }

  function myFactory( /* DI */ ) {
    // factory returns an object
    // you can run some code before
    function sayHello(name) {
      return "Hi " + name + "!";
    }
    function fullGreeting(n) {
      return "Greetings;" + sayHello(n);
    }
    return {
      sayHello: sayHello,
      fullGreeting: fullGreeting
    };
  }

  function justSayHello( /* DI */ ) {
    return function justSayHello(name) {
      return "Hi " + name + "!";
    };
  }

  function JustSayHelloService() {
      this.justSayHello = function (name) {
          return "Hi " + name + "!";
      }
  }

  angular.module('apiExamples', [])
    .component('apiExamples', {
      templateUrl: 'services.html',
      controller: ApiExampleController
    })
  .service('myService', MyService)
  .factory('myFactory', myFactory)
  .factory('justSayHello', justSayHello)
  .service('justSayHelloService', JustSayHelloService);

})(window.angular);
