# Workshop for this step

* Remove the data from your controllers
* Move them into services
* Inject and utilize new service
* Move your service to a different module and depend on it
* Move your service and its module to another file and load it
* Extra credit: make a factory that works the same as your service
