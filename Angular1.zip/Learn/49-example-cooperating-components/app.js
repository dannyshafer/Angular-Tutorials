(function (angular) {
  "use strict";

  angular.module('exampleApp', ['tabset']);

})(window.angular);
