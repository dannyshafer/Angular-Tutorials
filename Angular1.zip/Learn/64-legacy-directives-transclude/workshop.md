# Workshop for this step

1. Create a simple element directive (for example wrap an input and its label together)
2. Display said directive
