# Workshop for this step

1. Create a Javascript file
2. Create Module
3. Create a controller
4. inside that controller establish an array of data
5. display the data on the screen
6. create input that filters the data by one property
