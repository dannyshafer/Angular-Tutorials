# Workshop for this step

* In your service, instead of returning the HTTP promise, return a promise that extracts the data for you.
* Extra credit - add .thens that log the results
* Extra extra credit - use ES6 arrow functions
