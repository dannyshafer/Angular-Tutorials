# Workshop for this step

* Load a second source of data for your application
* Do some processing that requires both, and gets the data for both of them simultaneously, not sequentially
