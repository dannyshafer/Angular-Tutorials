# Workshop for this step

1. Create a new folder in "Learn"
2. Create a new index.html
3. Add ng-app
4. Add the angular library
5. Place a simple binding on the screen
