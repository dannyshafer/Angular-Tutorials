# Workshop for this step

* ng-src for image
* make use of ngShow/ngHide
* make use of ngIf
* make use of ngClass
* make use of ngSwitch/ngSwitchWhen/ngSwitchDefault
* Extra credit - make use of ngRepeatStart/ngRepeatEnd

# Cumulative Workshop

* Create your own folder
* Demo data
* load via $http in a service, return promise, in its own file/module
* Chain promise from above service
* List display component (directive), isolate scope, bind in data
* Search using filter filter
* Button with click handler
* img with ng-src
* Format based on data with ng-class or ng-show or ng-if etc
