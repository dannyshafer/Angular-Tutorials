
These sample mobile phone images are from the Google "Angular Phonecat" demo application.
