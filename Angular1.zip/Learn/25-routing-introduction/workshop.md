# Workshop for this step

1. In this example code, add an additional route (maybe an about page?)
2. In your application, add a welcome page
