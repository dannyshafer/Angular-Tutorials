(function (angular) {
  "use strict";

  angular.module("AddressApp", [
    "addressBook"
  ]);

})(window.angular);
