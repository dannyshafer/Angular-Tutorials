  # Workshop for this step

1. Create a simple component (for example wrap an input and its label together)
2. Display said component
3. Extra credit: Make a component that uses transclusion
