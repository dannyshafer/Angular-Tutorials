(function (angular) {
  "use strict";

  angular.module('app', ['exampleA', 'exampleB', 'exampleC']);

})(window.angular);
