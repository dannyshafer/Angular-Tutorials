# Workshop for this step

1. create components, associated with controllers instead
