# Workshop for this step

* create component directives, associated with controllers instead
