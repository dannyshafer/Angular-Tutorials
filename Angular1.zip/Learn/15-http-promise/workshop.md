# Workshop for this step

* Move data to a json file
* Replace data in service with $http call
* Extract data from promise in the controller
