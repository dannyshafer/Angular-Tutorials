# Workshop for this step

* create a custom filter
* apply it to your data
