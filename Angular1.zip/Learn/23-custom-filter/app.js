(function (angular) {
  "use strict";

  angular.module('app1', ['someFilters'])
    .component('countryView', {
      templateUrl: 'country-detail.html',
      controller: CountryDetailController,
      controllerAs: 'cd'
    });

  function CountryDetailController($http) {
    var vm = this;
    $http.get('../demo-data/usa.json').then(function (response) {
      vm.country = response.data;
    });
  }

})(window.angular);
