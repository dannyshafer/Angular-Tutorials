# Workshop for this step

1. Add another component, in a separate file.
2. Use your new component at level 5 within
   the existing component hierarchy.
