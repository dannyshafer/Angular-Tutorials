import {Component} from '@angular/core';

import {RedBox} from './red';
import {GreenCard} from './green';

@Component({
  selector: 'my-app',
  template: `
    <h4>Example application showing component nesting</h4>
    <red-card></red-card>
    <green-card></green-card>
  `,
  directives: [RedBox, GreenCard]
})
export class AppComponent { }
