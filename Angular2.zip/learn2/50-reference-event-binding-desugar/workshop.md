# Workshop for this step

1. Catch at least one event (click, mouseenter, blur)
