# Workshop for this step

1. Put a few more member/fields in the component class.
2. Add data to the properties.
3. Bind to them.
4. Experiment with HTML in the binding strings.
