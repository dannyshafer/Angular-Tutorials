# Workshop for this step

Use routing in your application:

1. Divide your app into at least 2 separate screens.
   You might need to begin with a placeholder for the screens
   you have not been working yet.
2. If you still have much of your code in one main screen,
   move some of it to another screen.
3. Add routing imports.
4. Route between screens.
