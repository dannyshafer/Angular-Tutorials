import {Injectable} from '@angular/core';

@Injectable()
export class GreetingCalculator {
  greeting() {
    return 'Hello, World';
  }
}
