import {Component} from '@angular/core';
import {ROUTER_DIRECTIVES} from '@angular/router';

declare var __moduleName: string;

@Component({
  moduleId: __moduleName,
  templateUrl: './contacts.component.html',
  directives: [ROUTER_DIRECTIVES]
})
export class Contacts {

}
