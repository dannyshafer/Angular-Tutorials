import {Component} from '@angular/core';

@Component({
  selector: 'welcome',
  template: `
    <h4>Welcome to the Routing Application</h4>
  `
})
export class Welcome {

}
