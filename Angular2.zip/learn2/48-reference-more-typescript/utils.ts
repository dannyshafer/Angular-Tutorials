
export class Helper {

  helpMe() {
    return 42;
  }
}
