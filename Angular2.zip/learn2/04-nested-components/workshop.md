# Workshop for this step

1. Add at least one more component to the application.
2. Use it inside the app component.
3. Inspect the DOM using the browser development tools.
4. (Optional) See what happens if you try to use components inside
   each other.
