# Workshop for this step

The work continues to fetch data using an API. Update the service you
created in the previous service to use HTTP and RxJS to asynchronously
fetch the data. Return the observable to your component and subscribe
to it.
