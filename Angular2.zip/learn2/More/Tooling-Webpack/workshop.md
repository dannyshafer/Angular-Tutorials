# Workshop

1. Select a few components and add them to the working
   Webpack example. 
2. Use require() to load your templates
3. Adjust paths as needed (remove .ts from imports)
4. Observe the bundle is still a single file.