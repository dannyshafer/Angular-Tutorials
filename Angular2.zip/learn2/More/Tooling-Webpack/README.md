# A2 Tooling with Webpack

I started with something like this; but ran more commands,
not included here yet.

```
npm install --save webpack @angular\core zone.js reflect-metadata
```

The above command is incomplete though; you need to list all of the various Angular modules you want to use.


## To Run

```
npm install
npm start
```

There are many *much* more complex Webpack examples online, for Angular 2.
It is unclear whether all that complexity is needed, or just preferred.
It is clear though, that while learning to use Webpack it is best to start simple.

