// This is NOT used by this example, rather it is pointing toward
// how libraries can be bundled separately.

// There are *much* more complex examples of Webpack use
// online, but we keep it very simple here for learning purposes.

// TODO actually bundle them.

// Angular 2
import '@angular/platform/browser';
import '@angular/platform/common_dom';
import '@angular/core';
import '@angular/router';
import '@angular/http';

// RxJS
import 'rxjs';

// could add others, like Lodash and Firebase
