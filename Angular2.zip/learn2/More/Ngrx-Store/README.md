# ngrx Store Example

The development kit here operates like the Tooling-SystemJS example,
with very little complexity.

The library demonstrated here does not depend on this particular tooling set up though; it can just as easily be used with Webpack or Angular-CLI.
