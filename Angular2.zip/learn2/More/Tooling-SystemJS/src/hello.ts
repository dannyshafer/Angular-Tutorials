import {Component} from 'angular2/core';

@Component({
  selector: 'hello',
  template: "<h3>Hi mom, from the Hello Component</h3>"
})
export class Hello {

}
