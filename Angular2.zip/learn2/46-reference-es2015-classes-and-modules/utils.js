// Note that we don't specify the name of a module anywhere;
// its filename is its name.

export class Helper {

  helpMe() {
    return 42;
  }
}
