# Workshop for this step

1. Consider the components you have created; choose one that you can
   imagine reusing widely.
2. Register it application-wide as shown here.
3. Change the code which uses this component, to do so without using
   the directives array.
