import {Component} from '@angular/core';

@Component({
  selector: 'widely-used-component',
  template: `
  <div class="card">
    <div class="card-content">
      <div class="card-title">This is a widely used component</div>
    </div>
  </div>
  `
})
export class WidelyUsedComponent { }
