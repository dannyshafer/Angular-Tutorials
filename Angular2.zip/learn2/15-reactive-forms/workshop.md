# Workshop for this step

The UI/UX team has suggested another improvement to the user experience.
The message informing the user that the character name is required is not well
received if it appears before the user has had the chance to interact with
the control.

Delay the appearance of the message until the user has clicked into the input
and clicked away without supplying a name.

To achieve this you will need to use Angular's form validation.
