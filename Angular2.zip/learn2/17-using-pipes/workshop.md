# Workshop for this step

The data for height that you have received is in inches. This is not the
greatest way to display the height of the archetypes. Create and use a filter
that converts the height from inches to feet.

## Step 1: Generate new pipe

Issue the following command from the terminal:

```
ng generate pipe inchToFeet
```

## Step 2: Modify the transform function to perform the correct translation
