# Workshop for this step

Progress continues, and it is now time to prep the application to
retrieve data from the server API. A key piece to preparing the
application for this process is to refactor the current collection of
components to obtain their static data from a "service".

Create a new service. This service should contain a function that will
return the JSON. Call this function where appropriate.

(This step is still not using AJAX requests.)

